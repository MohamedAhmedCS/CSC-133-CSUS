package com.mycompany.a4;

import com.codename1.ui.Graphics;

/**
 * Interface IDrawable defines a contract for drawable objects in a graphical application.
 * Classes implementing this interface are responsible for drawing themselves using the provided Graphics context.
 */
public interface IDrawable {

    /**
     * Draws the object on the provided Graphics context.
     * 
     * @param g The Graphics context to be used for drawing.
     */
    public void draw(Graphics g);
}
