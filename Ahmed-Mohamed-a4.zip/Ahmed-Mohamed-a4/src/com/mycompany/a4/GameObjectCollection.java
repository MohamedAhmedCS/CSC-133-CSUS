package com.mycompany.a4;

import java.util.Vector;

/**
 * GameObjectCollection class manages a collection of GameObjects.
 * It implements the ICollection interface and uses a Vector to store the objects.
 */
public class GameObjectCollection implements ICollection {
    private Vector<GameObject> collection = new Vector<GameObject>();

    /**
     * Returns an iterator to iterate over the objects in the collection.
     * 
     * @return An IIterator to iterate over the collection.
     */
    public IIterator getIterator() {
        return new ObjectIterator();
    }

    /**
     * Adds an object to the collection.
     * 
     * @param object The GameObject to add to the collection.
     */
    @Override
    public void add(GameObject object) {
        collection.add(object);
    }

    /**
     * Removes all the objects from the collection.
     */
    @Override
    public void clear() {
        collection.clear();
    }

    /**
     * Removes an object from the collection.
     * 
     * @param object The GameObject to remove from the collection.
     */
    @Override
    public void remove(GameObject object) {
        collection.remove(object);
    }

    /**
     * Inner class ObjectIterator provides a way to iterate over the GameObjects in the collection.
     */
    private class ObjectIterator implements IIterator {
        private int index = 0;

        /**
         * Checks if there are more objects in the collection.
         * 
         * @return True if there is another object in the collection, false otherwise.
         */
        @Override
        public boolean hasNext() {
            return index < collection.size();
        }

        /**
         * Retrieves the next GameObject in the collection.
         * 
         * @return The next GameObject in the collection, or null if there are no more objects.
         */
        @Override
        public GameObject getNext() {
            if (this.hasNext()) {
                return collection.elementAt(this.index++);
            }
            return null;
        }
    }
}
