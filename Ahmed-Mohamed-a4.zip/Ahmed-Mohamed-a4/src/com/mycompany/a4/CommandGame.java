package com.mycompany.a4;

import com.codename1.ui.CheckBox;
import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.events.ActionEvent;

/**
 * CommandGame class represents various commands related to the game such as exiting the game,
 * toggling sound, and displaying about/help information.
 */
public class CommandGame extends Command {
    private GameWorld gw;

    /**
     * Constructor for GameCommand.
     * 
     * @param command The name of the command.
     * @param gw      The GameWorld object on which the command acts.
     */
    public CommandGame(String command, GameWorld gw) {
        super(command);
        this.gw = gw;
    }

    /**
     * Executes the appropriate action based on the command's name.
     * 
     * @param event The action event that triggered the command.
     */
    @Override
    public void actionPerformed(ActionEvent event) {
        switch (this.getCommandName()) {
            case "Exit":  // Exit the application.
                boolean quit = Dialog.show("Confirm quit?", "Are you sure you want to quit?", "OK", "Cancel");
                if (quit) {
                    Display.getInstance().exitApplication();
                }
                break;
            case "Enable Sound":  // Toggle sound.
                boolean enabled = ((CheckBox)event.getComponent()).isSelected();
                gw.setSoundEnabled(enabled);
                break;
            case "About":  // Display application metadata.
                String about = "Mohamed Ahmed\nClass: CSC 133\nProfessor: Dr. Muyan\nAssignment: A4Prj";
                Dialog.show("About", about, "OK", null);
                break;
            case "Help":  // Show help information.
                String help = "A: Accelerate\nB: Brake\nL: Turn Left\nR: Turn Right\n";
                Dialog.show("Commands", help, "OK", null);
                break;
        }
    }
}
