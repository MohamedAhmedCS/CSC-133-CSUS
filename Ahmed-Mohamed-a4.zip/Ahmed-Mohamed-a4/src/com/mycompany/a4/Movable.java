package com.mycompany.a4;

/**
 * Abstract class representing movable objects in the game.
 * Movable objects have a heading and a speed, and their position can change over time.
 */
public abstract class Movable extends GameObject {
    private static final int UNIT_CIRCLE_DEGREES = 360;
    private int heading;
    private int speed;
    
    /**
     * 
     * @param size The size of the object.
     * @param color The color of the object.
     * @param locationX The initial X coordinate of the object.
     * @param locationY The initial Y coordinate of the object.
     * @param initialSpeed The starting speed for the object.
     * @param initialHeading The starting direction the object travels in.
     */
    public Movable(int size, int color, float locationX, float locationY, int initialSpeed, int initialHeading) {
        super(size, color, locationX, locationY);
        this.speed = initialSpeed;
        this.heading = initialHeading;
    }
    
    /**
     * Updates the object's location internally by a single time unit based on its
     * current heading and speed.
     * 
     * @param milliseconds The number of milliseconds representing the time unit.
     */
    public void move(long milliseconds) {
        double headingInRadians = Math.toRadians(90 - heading);
        float deltaX = (float)(Math.cos(headingInRadians) * this.speed) * (float) milliseconds / 1000;
        float deltaY = (float)(Math.sin(headingInRadians) * this.speed) * (float) milliseconds / 1000;
        
        this.setLocationX(getLocationX() + deltaX);
        this.setLocationY(getLocationY() + deltaY);
    }
    
    /**
     * Setter for speed.
     * 
     * @param speed The new speed for the object.
     */
    public void setSpeed(int speed) {
        if (speed < 0) {
            speed = 0;
        }
        this.speed = speed;
    }
    
    /**
     * Getter for speed.
     * 
     * @return The object's current speed.
     */
    public int getSpeed() {
        return this.speed;
    }
    
    /**
     * Setter for heading.
     * 
     * @param heading The new heading for the object.
     */
    public void setHeading(int heading) {
        this.heading = ((heading % UNIT_CIRCLE_DEGREES) + 360) % UNIT_CIRCLE_DEGREES;  // Keeps heading within [0, 360) degrees.
        this.setRotation((float)Math.toRadians(heading));
    }
    
    /**
     * Getter for heading.
     * 
     * @return The object's current heading.
     */
    public int getHeading() {
        return this.heading;
    }
    
    /**
     * Provides a string representation of the object's current state.
     * 
     * @return A string representing the object's current state.
     */
    public String toString() {
        String substate = super.toString();
        return "[Moveable] " + substate + ", Heading: " + this.heading + ", Speed: " + this.speed;
    }
}
