package com.mycompany.a4;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

/**
 * Represents the commands associated with the Ant in the game.
 * This class extends Command and is responsible for handling different
 * actions related to the Ant such as acceleration, braking, and steering.
 */
public class AntCommand extends Command {
    private GameWorld gw;

    /**
     * Constructor for AntCommand.
     * @param command The string name of the command.
     * @param gw The GameWorld instance which the command will manipulate.
     */
    public AntCommand(String command, GameWorld gw) {
        super(command);
        this.gw = gw;
    }

    /**
     * Handles the action to be performed when the command is invoked.
     * This method overrides the actionPerformed method from the Command class.
     * Depending on the command name, it calls the corresponding method in the GameWorld instance.
     * @param event The ActionEvent object generated when the command is invoked.
     */
    @Override
    public void actionPerformed(ActionEvent event) {
        switch (this.getCommandName()) {
            case "Accelerate":
                System.out.println("Accelerating the Ant...");
                gw.accelerateAnt();
                break;
            case "Brake":
                System.out.println("Decelerating the Ant...");
                gw.decelerateAnt();
                break;
            case "Left":
                System.out.println("Steering player left...");
                gw.turnAntLeft();
                break;
            case "Right":
                System.out.println("Steering player right...");
                gw.turnAntRight();
                break;
        }
    }
}
