package com.mycompany.a4;

/**
 * Interface ICollection defines the structure for a collection of GameObjects.
 * This interface includes methods to add, remove, and clear objects in the collection,
 * and to retrieve an iterator for traversing the collection.
 */
public interface ICollection {
    
    /**
     * Adds an object to the collection.
     * 
     * @param object The GameObject to be added to the collection.
     */
    public void add(GameObject object);
    
    /**
     * Removes an object from the collection.
     * 
     * @param object The GameObject to be removed from the collection.
     */
    public void remove(GameObject object);
    
    /**
     * Removes all objects from the collection.
     */
    public void clear();
    
    /**
     * Retrieves an iterator for the collection.
     * 
     * @return An IIterator instance to traverse through the collection.
     */
    public IIterator getIterator();
}

