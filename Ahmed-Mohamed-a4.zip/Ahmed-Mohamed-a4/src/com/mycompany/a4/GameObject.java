package com.mycompany.a4;

import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;

/**
 * Abstract class GameObject represents a basic game object.
 * It includes properties like size, color, and location, and provides methods for transformations and collision handling.
 */
public abstract class GameObject implements ICollider, IDrawable {
    private int size;
    private int color;

    private Transform myTranslate = Transform.makeIdentity();
    private Transform myRotate = Transform.makeIdentity();
    private Transform myScale = Transform.makeIdentity();

    /**
     * Constructor for GameObject.
     * 
     * @param size      Size of the object.
     * @param color     Color of the object.
     * @param locationX X-coordinate of the object's location.
     * @param locationY Y-coordinate of the object's location.
     */
    public GameObject(int size, int color, float locationX, float locationY) {
        this.size = size;
        this.color = color;
        translate(locationX, locationY);
    }

    /**
     * Moves the object's translation transform.
     * 
     * @param x Amount to move in the x direction.
     * @param y Amount to move in the y direction.
     */
    public void translate(float x, float y) {
        this.myTranslate.translate(x, y);
    }


    public void rotate(float angle) {
        this.myRotate.rotate(angle, 0, 0);
    }


    public void setRotation(float angle) {
        Transform rotation = Transform.makeIdentity();
        rotation.setRotation(-angle, -size/5, size);
        this.myRotate = rotation;
    }

    /**
     * Scales the object's scale transform.
     * 
     * @param x X scale factor.
     * @param y Y scale factor.
     */
    public void scale(float x, float y) {
        this.myTranslate.scale(x, y);
    }

    /**
     * Applies the local translation to the graphics object g.
     * 
     * @param g Graphics object to apply translation to.
     */
    public void applyTranslation(Graphics g) {
        Transform gXform = Transform.makeIdentity();
        g.getTransform(gXform);
        
        gXform.translate(myTranslate.getTranslateX(), myTranslate.getTranslateY());
        
        g.setTransform(gXform);
    }

    /**
     * Applies the local rotation to the graphics object g.
     * 
     * @param g Graphics object to apply rotation to.
     */
    public void applyRotation(Graphics g) {
        Transform gXform = Transform.makeIdentity();
        g.getTransform(gXform);
        
        gXform.concatenate(myRotate);
        
        g.setTransform(gXform);
    }

    /**
     * Applies the local scale to the graphics object g.
     * 
     * @param g Graphics object to apply scale to.
     */
    public void applyScale(Graphics g) {
        Transform gXform = Transform.makeIdentity();
        g.getTransform(gXform);
        
        gXform.concatenate(myScale);
        
        g.setTransform(gXform);
    }

    /**
     * Getter for size.
     * 
     * @return Current size of the object.
     */
    public int getSize() {
        return this.size;
    }

    /**
     * Setter for locationX.
     * 
     * @param x New X-coordinate for the object in the game space.
     */
    public void setLocationX(float x) {
        float dx = x - getLocationX();
        translate(dx, 0);
    }

    /**
     * Setter for locationY.
     * 
     * @param y New Y-coordinate for the object in the game space.
     */
    public void setLocationY(float y) {
        float dy = y - getLocationY();
        translate(0, dy);
    }

    /**
     * Getter for locationX.
     * 
     * @return Current X-coordinate of the object.
     */
    public float getLocationX() {
        return this.myTranslate.getTranslateX();
    }

    /**
     * Getter for locationY.
     * 
     * @return Current Y-coordinate of the object.
     */
    public float getLocationY() {
        return this.myTranslate.getTranslateY();
    }

    /**
     * Getter for color.
     * 
     * @return Current color of the object.
     */
    public int getColor() {
        return this.color;
    }

    /**
     * Setter for color.
     * 
     * @param color New color to set the object to.
     */
    public void setColor(int color) {
        this.color = color;
    }

    /**
     * Provides a string representation of the object's current state.
     * 
     * @return A string representing the object's current state.
     */
    @Override
    public String toString() {
        return "[GameObject] Location: (" + this.getLocationX() + ", " + this.getLocationY() + ") "
                + "Color: " + this.color + ", Size: " + this.size;
    }

    /**
     * Checks for collisions between two game objects.
     * 
     * @param otherObject The other GameObject to check collision with.
     * @return True if there is a collision, false otherwise.
     */
	@Override
	public boolean collidesWith(GameObject otherObject) {
		float thisLeft = this.getLocationX() - this.getSize() / 2;
		float otherLeft = otherObject.getLocationX() - otherObject.getSize() / 2;
		float thisRight = thisLeft + this.getSize();
		float otherRight = otherLeft + otherObject.getSize();
		
		// Check for lack of horizontal overlap for the objects.
		if (thisLeft > otherRight) {
			return false;
		}
		else if (thisRight < otherLeft) {
			return false;
		}
		
		float thisTop = this.getLocationY() + this.getSize() / 2;
		float otherTop = otherObject.getLocationY() + otherObject.getSize() / 2;
		float thisBottom = thisTop - this.getSize();
		float otherBottom = otherTop - otherObject.getSize();
		
		// Check for lack of vertical overlap for the objects.
		if (thisTop < otherBottom) {
			return false;
		}
		else if (thisBottom > otherTop) {
			return false;
		}
		
		// Otherwise, there must be overlap between the objects, hence they collide.
		return true;
	}
	
	/**
	 * Default behavior to handle the collision is to do nothing.
	 */
	@Override
	public void handleCollision(GameObject otherObject) {}
}
