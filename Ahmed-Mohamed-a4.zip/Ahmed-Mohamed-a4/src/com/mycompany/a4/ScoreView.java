package com.mycompany.a4;

import java.util.Observer;
import java.util.Observable;
import com.codename1.ui.Container;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.GridLayout;

/**
 * ScoreView class acts as an observer for the GameWorld.
 * It updates the display of game-related statistics such as the time,
 * player lives, last flag reached, food level, health level, and sound status.
 */
public class ScoreView extends Container implements Observer {
    private Label clockLabel = new Label();
    private Label livesLabel = new Label();
    private Label lastFlagLabel = new Label();
    private Label foodLevelLabel = new Label();
    private Label healthLevelLabel = new Label();
    private Label soundLabel = new Label();
    
    /**
     * Constructor for ScoreView.
     * Initializes the layout and the labels to display the initial game state.
     */
    public ScoreView() {
        this.setLayout(new GridLayout(1, 6));
        this.add(clockLabel);
        this.add(livesLabel);
        this.add(lastFlagLabel);
        this.add(foodLevelLabel);
        this.add(healthLevelLabel);
        this.add(soundLabel);
        
        clockLabel.setText("Time: 0");
        livesLabel.setText("Lives Left: 3");
        lastFlagLabel.setText("Last Flag Reached: 1");
        foodLevelLabel.setText("Food Level: 100");
        healthLevelLabel.setText("Health Level: 0");
        soundLabel.setText("Sound Enabled: OFF");
        
        int blueColor = 0x0000ff; // This is the color code for blue

        // Set each label's text color to blue
        clockLabel.getAllStyles().setFgColor(blueColor);
        livesLabel.getAllStyles().setFgColor(blueColor);
        lastFlagLabel.getAllStyles().setFgColor(blueColor);
        foodLevelLabel.getAllStyles().setFgColor(blueColor);
        healthLevelLabel.getAllStyles().setFgColor(blueColor);
        soundLabel.getAllStyles().setFgColor(blueColor);
    }
    
    /**
     * Updates the display based on changes in the observable GameWorld.
     * @param observable The observable object, typically an instance of GameWorld.
     * @param data Additional data passed to the notifyObservers method.
     */
    @Override
    public void update(Observable observable, Object data) {
        GameWorld gw = (GameWorld) observable;
        clockLabel.setText("Time: " + gw.getClock());
        livesLabel.setText("Lives Left: " + gw.getLives());
        lastFlagLabel.setText("Last Flag Reached: " + gw.getPlayerLastFlag());
        foodLevelLabel.setText("Food Level " + (int) gw.getAntFoodLevel());
        healthLevelLabel.setText("Health Level: " + gw.getHealth());
        soundLabel.setText("Sound Enabled: " + (gw.getSoundEnabled() ? "ON" : "OFF"));
    }
}
