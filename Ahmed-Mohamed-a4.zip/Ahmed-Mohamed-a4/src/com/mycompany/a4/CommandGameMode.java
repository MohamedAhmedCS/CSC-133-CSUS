package com.mycompany.a4;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a4.Game.Mode;

/**
 * CommandGameMode class represents a command to change the game mode in a Codename One application.
 * It extends the Command class and is designed to be linked to user interface elements like buttons.
 */
public class CommandGameMode extends Command {
    private Game target;

    /**
     * Constructor for GameModeCommand.
     * 
     * @param command The name of the command.
     * @param target  The Game object upon which the command will be invoked.
     */
    public CommandGameMode(String command, Game target) {
        super(command);
        this.target = target;
    }

    /**
     * Called when the associated button is clicked on.
     * 
     * @param event The action event triggering this command.
     */
    @Override
    public void actionPerformed(ActionEvent event) {
        switch (this.getCommandName()) {
            case "Play":  // Resume the game.
                target.setGameMode(Mode.PLAY);
                break;
            case "Pause":  // Pause the game.
                target.setGameMode(Mode.PAUSED);
                break;
        }
    }
}
