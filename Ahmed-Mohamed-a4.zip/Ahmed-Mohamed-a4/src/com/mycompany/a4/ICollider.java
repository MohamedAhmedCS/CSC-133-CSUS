package com.mycompany.a4;

/**
 * Interface ICollider defines the capabilities of objects that can detect and respond to collisions.
 * Classes implementing this interface must be able to check for collisions with other objects and handle them appropriately.
 */
public interface ICollider {

    /**
     * Checks if the current object collides with another specified object.
     * 
     * @param otherObject The other GameObject to check for a collision with.
     * @return True if a collision occurs, false otherwise.
     */
    public boolean collidesWith(GameObject otherObject);
    
    /**
     * Handles the collision with another object.
     * This method defines the actions to be taken when a collision is detected.
     * 
     * @param otherObject The GameObject that this object is colliding with.
     */
    public void handleCollision(GameObject otherObject);
}
