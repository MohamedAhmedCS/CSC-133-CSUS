package com.mycompany.a4;

import com.codename1.ui.geom.Point;

/**
 * Interface ISelectable defines the capabilities of an object that can be selected.
 * Classes implementing this interface can be marked as selected and can determine
 * if they contain a specific point within their boundaries.
 */
public interface ISelectable {

    /**
     * Setter for the selected state of the object.
     * 
     * @param selected The selected state to set.
     */
    public void setSelected(boolean selected);
    
    /**
     * Getter for the selected state of the object.
     * 
     * @return True if the object is currently selected, false otherwise.
     */
    public boolean isSelected();
    
    /**
     * Tests whether a given point is contained within the bounds of the object.
     * 
     * @param point The point to test.
     * @return True if the point is within the object's bounds, false otherwise.
     */
    public boolean contains(Point point);
}
