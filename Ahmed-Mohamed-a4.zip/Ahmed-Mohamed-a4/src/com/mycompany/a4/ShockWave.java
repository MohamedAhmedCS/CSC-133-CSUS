package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;

/**
 * Represents a ShockWave in the game, which is a type of movable entity.
 * The ShockWave class manages the graphical representation and behavior of
 * a shock wave, including its Bezier curve drawing and time-to-live (TTL) logic.
 */
public class ShockWave extends Movable {
    
    public static final int SIZE = 100;
    public static final int COLOR = ColorUtil.BLUE;
    public static final int SPEED = 200;
    public static final int TIME_TO_LIVE = 8000; // Milliseconds.
    private static final double EPSILON = 0.001;
    
    private Point[] controlPoints = new Point[4];
    private long ttl = TIME_TO_LIVE;
    
    /**
     * Constructor for ShockWave.
     * @param locationX The initial X coordinate of the shockwave.
     * @param locationY The initial Y coordinate of the shockwave.
     */
    public ShockWave(float locationX, float locationY) {
        super(SIZE, COLOR, locationX, locationY, SPEED, GameWorld.randomInt(0, 360));
        
        for (int i = 0; i < 4; i++) {
            int x = GameWorld.randomInt(-SIZE, SIZE);
            int y = GameWorld.randomInt(-SIZE, SIZE);
            controlPoints[i] = new Point(x, y);
        }
    }

    /**
     * Moves the ShockWave based on its current heading and speed.
     * Decreases the TTL (time-to-live) of the ShockWave.
     * @param milliseconds The time elapsed in milliseconds since the last update.
     */
    @Override
    public void move(long milliseconds) {
        super.move(milliseconds);
        ttl -= milliseconds;
    }

    /**
     * Checks whether the ShockWave has expired (its TTL has reached zero).
     * @return True if the ShockWave has expired, otherwise false.
     */
    public boolean isExpired() {
        return ttl <= 0;
    }

    /**
     * Draws the ShockWave on the screen using a Bezier curve.
     * @param g The graphics object used for drawing.
     */
    @Override
    public void draw(Graphics g) {
        Transform oldXform = Transform.makeIdentity();
        g.getTransform(oldXform);
        
        applyTranslation(g);
        applyRotation(g);
        applyScale(g);
        
        g.setColor(this.getColor());                
        drawBezierCurve(g, controlPoints);
        
        g.setTransform(oldXform);
    }

    /**
     * Draws a Bezier curve on the graphics context.
     * @param g The graphics context.
     * @param currentControlPoints The control points of the Bezier curve.
     */
    void drawBezierCurve(Graphics g, Point[] currentControlPoints) {
        if (straightEnough(currentControlPoints)) {
            double x1 = currentControlPoints[0].getX();
            double x2 = currentControlPoints[3].getX();
            double y1 = currentControlPoints[0].getY();
            double y2 = currentControlPoints[3].getY();
            
            g.drawLine((int) x1, (int) y1, (int) x2, (int) y2);
        }
        else {
            Point[] leftCurvePoints = new Point[4];
            Point[] rightCurvePoints = new Point[4];
            subdivideCurve(currentControlPoints, leftCurvePoints, rightCurvePoints);
            drawBezierCurve(g, leftCurvePoints);
            drawBezierCurve(g, rightCurvePoints);
        }
    }

    /**
     * Checks if the control points are straight enough to draw a line.
     * @param q The array of control points.
     * @return True if the points are straight enough, false otherwise.
     */
    boolean straightEnough(Point[] q) {
        double d1 = lengthBetween(q[0], q[1]) + lengthBetween(q[1], q[2]) + lengthBetween(q[2], q[3]);
        double d2 = lengthBetween(q[0], q[3]);
        return Math.abs(d1 - d2) <= EPSILON;  
    }

    /**
     * Subdivides a Bezier curve into two smaller curves.
     * @param q The original control points of the curve.
     * @param r The control points for the left subdivided curve.
     * @param s The control points for the right subdivided curve.
     */
    void subdivideCurve(Point[] q, Point[] r, Point[] s) {
        r[0] = q[0];
        r[1] = dividePoint(addPoints(q[0], q[1]), 2.0);
        r[2] = addPoints(dividePoint(r[1], 2.0), dividePoint(addPoints(q[1], q[2]), 4.0));
        s[3] = q[3];
        s[2] = dividePoint(addPoints(q[2], q[3]), 2.0);
        s[1] = addPoints(dividePoint(addPoints(q[1], q[2]), 4.0), dividePoint(s[2], 2.0));
        r[3] = dividePoint(addPoints(r[2], s[1]), 2.0);
        s[0] = r[3];
    }

    /**
     * Adds two points together and returns a new point of the result.
     * @param a The first point.
     * @param b The second point.
     * @return The resulting point after addition.
     */
    private Point addPoints(Point a, Point b) {
        return new Point(a.getX() + b.getX(), a.getY() + b.getY());
    }

    /**
     * Divides a point by a constant.
     * @param a The point to divide.
     * @param divisor The amount to divide by.
     * @return The resulting point after division.
     */
    private Point dividePoint(Point a, double divisor) {
        double x = a.getX() / divisor;
        double y = a.getY() / divisor;
        return new Point(x, y);
    }

    /**
     * Returns the length between two points.
     * @param a The first point.
     * @param b The second point.
     * @return The length between the two points.
     */
    private double lengthBetween(Point a, Point b) {
        double dx = b.getX() - a.getX();
        double dy = b.getY() - a.getY();
        return Math.sqrt((dx * dx) + (dy * dy));
    }

    /**
     * Inner class to represent a point in 2D space.
     */
    private class Point {
        private double x = 0;
        private double y = 0;
        
        /**
         * Constructor for the Point class.
         * @param x The initial x value.
         * @param y The initial y value.
         */
        Point(double x, double y) {
            this.x = x;
            this.y = y;
        }
        
        /**
         * Gets the x component of the point.
         * @return The x component.
         */
        public double getX() {
            return this.x;
        }
        
        /**
         * Gets the y component of the point.
         * @return The y component.
         */
        public double getY() {
            return this.y;
        }
    }
}
