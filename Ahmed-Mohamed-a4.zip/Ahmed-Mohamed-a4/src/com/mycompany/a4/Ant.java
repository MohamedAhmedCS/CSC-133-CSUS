package com.mycompany.a4;


/**
 * Represents an Ant in the game, which is a movable and steerable game object.
 * The Ant class is responsible for handling the movement and state of the ant, 
 * including its speed, heading, food level, and damage level.
 */
public abstract class Ant extends Movable implements ISteerable {
    public static final int MAX_STEER_INCREMENT = 5;  // Increment the heading changes by.
    public static final int MAX_STEER_VALUE = 40;  // Maximum steering value at a given time.
    public static final int ANT_SIZE = 100;
    public static final int DAMAGE_TO_OTHER_ENTITIES = 20;  // Damage do to other entities in a collision.
    public static final int INITIAL_FOOD_LEVEL = 500;
    public static final int INTIAL_MAX_SPEED = 100;

    private int steeringDirection = 0;
    private int maximumSpeed = INTIAL_MAX_SPEED;
    private float FoodLevel = INITIAL_FOOD_LEVEL;
    private int foodConsumptionRate = 5;
    private int healthLevel = 0;
    private int lastFlagReached = 1;
    private int minHealth = 0;

    /**
     * Constructor for Ant.
     * @param color The color of the ant.
     * @param locationX The initial X coordinate of the ant.
     * @param locationY The initial Y coordinate of the ant.
     * @param speed The initial speed of the ant.
     * @param heading The initial heading of the ant.
     * @param minHealth The maximum damage the ant can sustain before it is considered dead.
     */
	public Ant(int color, float locationX, float locationY, int speed, int heading, int minHealth) {
		super(ANT_SIZE, color, locationX, locationY, speed, heading);
		this.minHealth = minHealth;
	}
	

	@Override
	public void move(long milliseconds) {
		if (this.isDead()) {
			return;
		}
		super.setHeading(super.getHeading() + (int) (this.steeringDirection * (float) milliseconds / 1000));
		super.move(milliseconds);
		this.FoodLevel -= (float) this.foodConsumptionRate * ((float) milliseconds / 1000);
	}
	

	@Override
	public void setHeading(int newHeading) {}
	
    /**
     * Steers the Ant to the left by decreasing its steering direction.
     */
	@Override
	public void steerLeft() {
		this.steeringDirection -= MAX_STEER_INCREMENT;
		if (this.steeringDirection <= -MAX_STEER_VALUE) {
			this.steeringDirection = -MAX_STEER_VALUE;
		}
	}
	
    /**
     * Steers the Ant to the right by increasing its steering direction.
     */
	@Override
	public void steerRight() {
		this.steeringDirection += MAX_STEER_INCREMENT;
		if (this.steeringDirection >= MAX_STEER_VALUE) {
			this.steeringDirection = MAX_STEER_VALUE;
		}
	}
	

	public int getSteeringDirection() {
		return this.steeringDirection;
	}
	

	public int getMaximumSpeed() {
		return this.maximumSpeed;
	}
	

	public void setMaximumSpeed(int speed) {
		if (speed < 0) {  // Can't have negative max speed.
			speed = 0;
		}
		
		this.maximumSpeed = speed;
		this.setSpeed(this.getSpeed());  // Ensures the current speed is not larger than maximum speed.
	}
	
	/**
	 * Setter for the current speed.
	 * 
	 * @param speed			the new speed
	 */
	@Override
	public void setSpeed(int speed) {
		if (speed > this.maximumSpeed) {
			speed = this.maximumSpeed;
		}
		
		super.setSpeed(speed);
	}
	

	public int getLastFlagReached() {
		return this.lastFlagReached;
	}
	

	public void setLastFlagReached(int flag) {
				if (flag == this.lastFlagReached+ 1 ) {
			this.lastFlagReached = flag;
		}
	}
	

	public void modifyFoodLevel(int amount) {
		this.FoodLevel += amount;
	}
	

	public float getFoodLevel() {
		return this.FoodLevel;
	}
	

	public int getHealthLevel() {
		return this.healthLevel;
	}
	

	public void health(int amount) {
		this.healthLevel += amount;
		float healthPercentageRemaining = 1f - ((float) this.healthLevel / this.minHealth);
		int newMaxSpeed = (int)(healthPercentageRemaining * INTIAL_MAX_SPEED);  
		this.setMaximumSpeed(newMaxSpeed);
	}
	

	public String toString() {
		String state = super.toString();
		return "[Ant] " + state + ", Last Flag: " + this.lastFlagReached + 
				", Food: " + this.FoodLevel + 
				", Health: " + this.healthLevel + 
				", Max Speed: " + this.maximumSpeed + 
				", Steering: " + this.steeringDirection;
	}
	
    /**
     * Checks whether the Ant is dead, either due to damage or lack of food.
     * @return True if the Ant is dead, otherwise false.
     */
	public boolean isDead() {
		return this.healthLevel >= this.minHealth || this.FoodLevel <= 0;
	}
	

	public int getFoodConsumptionRate() {
		return this.foodConsumptionRate;
	}
	

    /**
     * Handles the collision of the Ant with other game objects.
     * @param otherObject The other game object with which the Ant collides.
     */
	@Override
	public void handleCollision(GameObject otherObject) {
		if (otherObject instanceof Spider) {
			this.health(Spider.DAMAGE_TO_OTHER_ENTITIES);
			GameWorld.playSpiderSound();
		}
	
		else if (otherObject instanceof Flag) {
			Flag flag = (Flag) otherObject;
			if (flag.getSequenceNumber() == getLastFlagReached() + 1) {
				this.setLastFlagReached(flag.getSequenceNumber());
			}
		}
		else if (otherObject instanceof FoodStation) {
			FoodStation station = (FoodStation) otherObject;
			if (station.hasFood()) {
				this.modifyFoodLevel(station.drainFood());
				GameWorld.playFoodSound();
			}
		}
	}
}
