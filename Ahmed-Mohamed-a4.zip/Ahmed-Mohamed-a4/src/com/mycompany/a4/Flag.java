package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;

/**
 * The Flag class represents a flag object in the game.
 * It inherits from the Fixed class, indicating that flags are stationary objects.
 */
public class Flag extends Fixed {
    private static final int Flag_SIZE = 100; 
    private int sequenceNumber;

    /**
     * Constructor for the Flag class.
     * 
     * @param color          The color of the flag.
     * @param locationX      The X coordinate of the flag's location.
     * @param locationY      The Y coordinate of the flag's location.
     * @param sequenceNumber The sequence number of the flag, indicating its order in the game.
     */
    public Flag(int color, float locationX, float locationY, int sequenceNumber) {
        super(Flag_SIZE, color, locationX, locationY);
        this.sequenceNumber = sequenceNumber;
    }

    /**
     * Getter for the sequence number of the flag.
     * 
     * @return The sequence number of the flag.
     */
    public int getSequenceNumber() {
        return this.sequenceNumber;
    }

    /**
     * Provides a string representation of the flag's current state.
     * 
     * @return A string detailing the flag's properties.
     */
    @Override
    public String toString() {
        String state = super.toString();
        return "[Flag] " + state + ", Sequence #: " + this.sequenceNumber;
    }

    /**
     * Setter for color is overridden to do nothing as the color of a flag cannot be changed.
     * 
     * @param color The color for the flag (not used).
     */
    @Override
    public void setColor(int color) {}

    /**
     * Draws the flag on the screen. Flags are represented as triangles.
     * 
     * @param g The graphics object used for drawing.
     */
    @Override
    public void draw(Graphics g) {
        float x = -this.getSize() / 2;
        float y = -this.getSize() / 2;
        int[] xPoints = {(int) x, (int) (x + this.getSize()), (int) ((2 * x + this.getSize()) / 2)};
        int[] yPoints = {(int) y, (int) y, (int) (y + this.getSize())};

        Transform oldXform = Transform.makeIdentity();
        g.getTransform(oldXform);

        applyTranslation(g);
        applyRotation(g);
        applyScale(g);
        g.setColor(this.getColor());

        if (isSelected()) {
            g.drawPolygon(xPoints, yPoints, 3);
        } else {
            g.fillPolygon(xPoints, yPoints, 3);
        }

        g.setColor(ColorUtil.BLACK);

        // Invert the text.
        Transform t = Transform.makeIdentity();
        g.getTransform(t);
        t.scale(1, -1);
        g.setTransform(t);
        g.drawString(Integer.toString(this.sequenceNumber), (int) ((x * 2 + this.getSize()) / 2), (int) y - 200);

        g.setTransform(oldXform);
    }
}
