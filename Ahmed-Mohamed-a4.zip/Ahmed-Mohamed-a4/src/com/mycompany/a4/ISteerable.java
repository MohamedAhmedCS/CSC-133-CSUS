package com.mycompany.a4;

/**
 * Interface ISteerable defines the capabilities of a steerable object.
 * Classes implementing this interface can change their direction of movement.
 */
public interface ISteerable {
    
    /**
     * Change the steering direction slightly to the right (clockwise).
     */
    public abstract void steerRight();
    
    /**
     * Change the steering direction slightly to the left (counter-clockwise).
     */
    public abstract void steerLeft();
}
