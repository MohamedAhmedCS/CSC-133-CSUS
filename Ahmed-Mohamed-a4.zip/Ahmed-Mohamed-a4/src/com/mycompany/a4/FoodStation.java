package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;


/**
 * Represents a food station in the game.
 * Food stations are fixed objects which can provide food to the player.
 * The capacity of the food station is represented by its size.
 */
public class FoodStation extends Fixed implements ICollider {
    public static final int COLOR_FULL = ColorUtil.GREEN;  
    public static final int COLOR_EMPTY = ColorUtil.rgb(245, 105, 105);  // Light red color, represents food stations when they are empty.
    private int capacity;
    
    /**
     * Constructor for creating a FoodStation.
     * @param size The size of the food station, which also indicates its capacity.
     * @param locationX The X coordinate of the food station's location.
     * @param locationY The Y coordinate of the food station's location.
     */
    public FoodStation(int size, float locationX, float locationY) {
        super(size, COLOR_FULL, locationX, locationY);
        this.capacity = size;
    }
    
    /**
     * Drains the food from the station, setting its capacity to zero.
     * Changes the color of the station to indicate it is empty.
     * @return The amount of food drained (original capacity of the station).
     */
    public int drainFood() {
        int food = this.capacity;
        this.capacity = 0;
        this.setColor(COLOR_EMPTY);
        
        return food;
    }
    
    /**
     * Checks if the food station has any food left.
     * @return True if there is food available, otherwise false.
     */
    public boolean hasFood() {
        return this.capacity > 0;
    }
    
    /**
     * Provides a string representation of the food station's state.
     * @return A string detailing the food station's properties.
     */
    @Override
    public String toString() {
        String state = super.toString();
        return "[FoodStation] " + state + ", Capacity: " + this.capacity;
    }
    
    /**
     * Draws the food station on the screen.
     * Represents the station with a circle whose size is proportional to its capacity.
     * @param g The graphics object used for drawing.
     */
    @Override
	public void draw(Graphics g) {
		float x = -this.getSize() / 2;
		float y = -this.getSize() / 2;				
		Transform oldXform = Transform.makeIdentity();
		g.getTransform(oldXform);
		
		applyTranslation(g);
		applyRotation(g);
		applyScale(g);
		g.setColor(this.getColor());
		int size = this.getSize();
		
		if (isSelected()) {
			g.drawRect((int) x, (int) y, size, size);
		}
		else {
			g.fillRect((int) x, (int) y, size, size);
		}
		
		// Invert the text.
		Transform t = Transform.makeIdentity();
		g.getTransform(t);
		t.scale(1, -1);
		g.setTransform(t);
		g.setColor(ColorUtil.BLACK);
		g.drawString(Integer.toString(this.capacity), (int) ((x * 2 + this.getSize()) / 2), (int) y - 200);
		
		g.setTransform(oldXform);
	}
}
