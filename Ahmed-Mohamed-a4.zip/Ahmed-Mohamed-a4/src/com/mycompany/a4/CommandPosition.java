package com.mycompany.a4;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

/**
 * CommandPosition class represents a command to set the position of an object in the game world.
 * It extends the Codename One Command class and is designed to be linked to a user interface element.
 */
public class CommandPosition extends Command {
    private GameWorld gw;

    /**
     * Constructor for PositionCommand.
     * 
     * @param target The GameWorld where the action will be applied.
     */
    public CommandPosition(GameWorld target) {
        super("Position");
        this.gw = target;
    }

    /**
     * Called when the associated button is pressed.
     * 
     * @param event The action event triggering this command.
     */
    @Override
    public void actionPerformed(ActionEvent event) {
        switch (this.getCommandName()) {
        case "Position":
            this.gw.setMovingObject(true);
            break;
        }
    }
}
