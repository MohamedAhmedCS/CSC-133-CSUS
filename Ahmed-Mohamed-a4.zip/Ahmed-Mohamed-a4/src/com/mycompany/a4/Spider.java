package com.mycompany.a4;
import java.util.Random;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;

/**
 * Represents a Spider in the game, which is a type of movable entity.
 * The Spider class manages the movement behavior of the spider, including
 * its heading changes and interactions with the world boundaries.
 */
public class Spider extends Movable {
    private static final int MAX_HEADING_INCREMENT = 5;
    public static final int DAMAGE_TO_OTHER_ENTITIES = 20;
    
    private int worldBoundX;
    private int worldBoundY;

    /**
     * Constructor for Spider.
     * @param size The size of the spider.
     * @param color The color of the spider.
     * @param locationX The initial X coordinate of the spider.
     * @param locationY The initial Y coordinate of the spider.
     * @param initialSpeed The initial speed of the spider.
     * @param initialHeading The initial heading of the spider.
     * @param worldBoundX The maximum X boundary of the spider's world.
     * @param worldBoundY The maximum Y boundary of the spider's world.
     */
    public Spider(int size, int color, float locationX, float locationY, int initialSpeed, int initialHeading, int worldBoundX, int worldBoundY) {
        super(size, color, locationX, locationY, initialSpeed, initialHeading);
        this.worldBoundX = worldBoundX;
        this.worldBoundY = worldBoundY;
    }

    /**
     * Moves the Spider based on its current heading and speed.
     * The Spider's heading changes randomly, and it reflects off world boundaries.
     * @param milliseconds The time elapsed in milliseconds since the last update.
     */
    @Override
    public void move(long milliseconds) {
        int heading = getHeading();
        Random generator = new Random(System.currentTimeMillis());
        
        int headingIncrement = generator.nextInt(MAX_HEADING_INCREMENT);
        boolean negative = generator.nextBoolean();
        if (negative) {
            headingIncrement = -headingIncrement;
        }
        
        this.hiddenSetHeading(heading + headingIncrement);
        super.move(milliseconds);
        
        if (getLocationX() >= this.worldBoundX || getLocationX() <= 0) {
            int reflectedHeadingX = -getHeading();
            hiddenSetHeading(reflectedHeadingX);
        }
        
        if (getLocationY() >= this.worldBoundY || getLocationY() <= 0) {
            int reflectedHeadingY = 180 - getHeading();
            hiddenSetHeading(reflectedHeadingY);
        }
    }

    /**
     * Sets the Spider's heading. This method is overridden to prevent external changes to the heading.
     * @param newHeading The new heading of the Spider.
     */
    @Override
    public void setHeading(int newHeading) {}

    /**
     * Sets the color of the Spider. This method is overridden to prevent changing the color of the Spider.
     * @param color The new color of the Spider.
     */
    @Override
    public void setColor(int color) {}  

    /**
     * Provides a string representation of the Spider's state.
     * @return A string detailing the Spider's properties.
     */
    public String toString() {
        String substate = super.toString();
        return "[Spider] " + substate;
    }

    /**
     * Draws the Spider on the screen.
     * Represents the Spider with a triangle whose size is proportional to its size attribute.
     * @param g The graphics object used for drawing.
     */
    @Override
    public void draw(Graphics g) {
        float x = -this.getSize() / 2;
        float y = -this.getSize() / 2;
                
        Transform oldXform = Transform.makeIdentity();
        g.getTransform(oldXform);
        
        applyTranslation(g);
        applyRotation(g);
        applyScale(g);
        g.setColor(this.getColor());
        
        int[] xPoints = {(int) x, (int) (x + this.getSize()), (int) ((2 * x + this.getSize()) / 2)};  // X locations of triangle points.
        int[] yPoints = {(int) y, (int) y, (int) (y + this.getSize())};  // Y locations of triangle points.
        
        g.setColor(this.getColor());
        g.drawPolygon(xPoints, yPoints, 3);
        
        g.setTransform(oldXform);
    }

    /**
     * Private method to internally change the Spider's heading.
     * @param newHeading The new heading of the Spider.
     */
    private void hiddenSetHeading(int newHeading) {
        super.setHeading(newHeading);
    }
}
