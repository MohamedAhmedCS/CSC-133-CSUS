package com.mycompany.a4;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;



/**
 * Represents the appearance of an ant in a graphical application.
 * This class extends the Ant class, adding specific graphical
 * representations for the ant, such as drawing its body and legs.
 * It uses the Singleton pattern to ensure only one instance exists.
 */
public class AntAppearance extends Ant {
	private static AntAppearance instance;
	private static final int PLAYER_ANT_COLOR = ColorUtil.rgb(255, 0, 0);
	private static float initialX = 0;
	private static float initialY = 0;
	private static int armSpeed = 35;
	private static float currentArmDisplacement = 0;
	private static final int ARM_MOVEMENT_DISTANCE = 25;
	
    /**
     * Private constructor for the Singleton pattern.
     */
	private AntAppearance() {
		super(PLAYER_ANT_COLOR, initialX, initialY, 10, 0, 100);		
	}
	
	 /**
     * Provides the Singleton instance of the AntAppearance class.
     * @return The single instance of AntAppearance.
     */
	public static AntAppearance getInstance() {
		if (instance == null) {
			instance = new AntAppearance();
		}
		
		return instance;
	}
    /**
     * Resets and returns the Singleton instance of the AntAppearance class.
     * @return The reset instance of AntAppearance.
     */

	public static AntAppearance resetInstance() {
		instance = null;
		return getInstance();
	}
	
    /**
     * Sets the initial location of the ant.
     * @param x X-coordinate of the initial location.
     * @param y Y-coordinate of the initial location.
     */
	public static void setInitialLocation(float x, float y) {
		initialX = x;
		initialY = y;
	}
	
    /**
     * Draws the graphical representation of the ant.
     * @param g The graphics context used for drawing.
     */
	@Override
	public void draw(Graphics g) {        
	    Transform oldXform = Transform.makeIdentity();
	    g.getTransform(oldXform);
	    
	    applyTranslation(g);
	    applyRotation(g);
	    applyScale(g);
	    
	    // Body dimensions
	    int bodyHeight = this.getSize() * 3; // Larger height for a vertical oval (the body of the ant)
	    int bodyWidth = this.getSize(); // Width of the body
	    // Head dimensions
	    int headWidth = bodyWidth * 3 / 4; // Head width, three-fourths of the body width
	    int headHeight = bodyWidth / 2; // Head height, half the body width for an elongated shape
	    
	    int bodyX = -bodyWidth / 2; // Center x-coordinate for the body oval
	    int bodyY = -bodyHeight / 2; // Center y-coordinate for the body oval
	    
	    g.setColor(getColor());
	    // Draw the vertical oval body
	    g.fillArc(bodyX, bodyY, bodyWidth, bodyHeight, 0, 360);
	    
	    // Draw the head of the body
	    int headX = bodyX + (bodyWidth - headWidth) / 2; // Center the head horizontally relative to the body
	    int headY = bodyY + bodyHeight - headHeight / 2; 
	    g.setColor(ColorUtil.BLACK); // Set the color for the head
	    g.fillArc(headX, headY, headWidth, headHeight, 0, 360);
	    
	    // Legs color
	    g.setColor(ColorUtil.BLACK); // Set the color for the legs to black
	    
	    // Calculate leg positions and draw them
	    int numLegsPerSide = 3; // Number of legs on each side
	    int legSpacing = bodyHeight / (numLegsPerSide + 1); // Space out the legs along the height of the body
	    int legLength = bodyWidth / 4; // Length of the legs
	    
	    for (int i = 1; i <= numLegsPerSide; i++) { // Draw three legs on each side
	        int legY = bodyY + i * legSpacing;
	        
	        // Left legs
	        int[] xPointsLeft = {bodyX, bodyX - legLength, bodyX};
	        int[] yPointsLeft = {legY, legY, legY + legLength};
	        // Apply dynamic transformation to left legs
	        for (int j = 0; j < xPointsLeft.length; j++) {
	            xPointsLeft[j] -= (int)currentArmDisplacement;
	        }
	        g.fillPolygon(xPointsLeft, yPointsLeft, 3);
	        
	        // Right legs
	        int[] xPointsRight = {bodyX + bodyWidth, bodyX + bodyWidth + legLength, bodyX + bodyWidth};
	        int[] yPointsRight = {legY, legY, legY + legLength};
	        // Apply dynamic transformation to right legs
	        for (int j = 0; j < xPointsRight.length; j++) {
	            xPointsRight[j] += (int)currentArmDisplacement;
	        }
	        g.fillPolygon(xPointsRight, yPointsRight, 3);
	    }
	    
	    g.setTransform(oldXform);
	}

    /**
     * Moves the ant and updates its leg movement.
     * @param milliseconds The time elapsed in milliseconds.
     */
	@Override
	public void move(long milliseconds) {
		super.move(milliseconds);
		
		currentArmDisplacement += armSpeed * (((float)milliseconds) / 1000);
		
		if (currentArmDisplacement <= 0) {
			currentArmDisplacement = 0;
			armSpeed *= -1;
		}
		
		if (currentArmDisplacement >= ARM_MOVEMENT_DISTANCE) {
			currentArmDisplacement = ARM_MOVEMENT_DISTANCE;
			armSpeed *= -1;
		}
	}
}