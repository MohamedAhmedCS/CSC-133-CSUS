package com.mycompany.a4;

/**
 * Interface IIterator defines the structure for an iterator over a collection of GameObjects.
 * It provides methods to check if there are more elements in the collection and to retrieve the next element.
 */
public interface IIterator {
    
    /**
     * Checks if there is another object in the collection that has not been processed yet.
     * 
     * @return True if there is another object in the collection, false otherwise.
     */
    public abstract boolean hasNext();
    
    /**
     * Retrieves the next object in the collection, if available.
     * 
     * @return The next GameObject in the collection.
     */
    public abstract GameObject getNext();
}
