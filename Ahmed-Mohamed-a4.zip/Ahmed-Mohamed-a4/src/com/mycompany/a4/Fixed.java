package com.mycompany.a4;

import com.codename1.ui.geom.Point;

/**
 * Abstract class Fixed represents fixed (non-movable) objects in the game.
 * It extends GameObject and implements ISelectable, indicating that these objects can be selected.
 */
public abstract class Fixed extends GameObject implements ISelectable {
    private boolean selected = false;

    /**
     * Constructor for the Fixed class.
     * 
     * @param size      Size of the object.
     * @param color     Color of the object.
     * @param locationX X-coordinate of the object's location.
     * @param locationY Y-coordinate of the object's location.
     */
    public Fixed(int size, int color, float locationX, float locationY) {
        super(size, color, locationX, locationY);
    }

    /**
     * Provides a string representation of the fixed object's current state.
     * 
     * @return A string detailing the fixed object's properties.
     */
    @Override
    public String toString() {
        String state = super.toString();
        return "[Fixed] " + state;
    }

    /**
     * Setter for the selected state of the object.
     * 
     * @param selected New selected state of the object.
     */
    @Override
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    /**
     * Getter for the selected state of the object.
     * 
     * @return True if the object is currently selected, false otherwise.
     */
    @Override
    public boolean isSelected() {
        return this.selected;
    }

    /**
     * Determines whether a given point is within the bounds of the object.
     * 
     * @param point The point to check.
     * @return True if the point is within the object's bounds, false otherwise.
     */
    @Override
    public boolean contains(Point point) {
        int x = point.getX();
        int y = point.getY();
        float posX = this.getLocationX();
        float posY = this.getLocationY();
        float radius = this.getSize() / 2;
        
        if (x < posX - radius || x > posX + radius) {
            return false;
        }
        
        if (y < posY - radius || y > posY + radius) {
            return false;
        }
        
        return true;
    }
}
